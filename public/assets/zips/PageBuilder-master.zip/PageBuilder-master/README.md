# PageBuilder
This is a PageBuilder project built by HTML, CSS, and JavaScript. Fully responsive for phones tablets etc...
You simply put the details you want, click on the add button and the element will pop up on the left side of the screen. 
On phones, the element will pop below the inputs.
